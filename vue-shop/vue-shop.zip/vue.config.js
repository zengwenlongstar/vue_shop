module.exports = {
    lintOnSave: false,
}